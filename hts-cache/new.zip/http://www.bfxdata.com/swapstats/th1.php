<html>
<head>
	<title>
		404 Page not found
	</title>

	<style>
	* { font-family: verdana; font-size: 11pt; COLOR: gray; }
	b { font-weight: bold; }
	table { height: 50%; border: 1px solid gray;}
	td { text-align: left; padding: 25;}

	</style>
</head>
<body>
<center>
<br><br><br><br>
	<table>
	<tr><td><h1 style="font-size: 16pt">Ooops 404 not found :'(</h1><br>
		
		Go back to <a href="http://www.bfxdata.com">Bfxdata.com</a><br>

 </td></tr>

<tr><td> Bitfinex referrer code: <a href="https://www.bitfinex.com/?refcode=UttOzlC1zZ" target="_blank">UttOzlC1zZ</a><br>

Bitcoin: 1EU22zLeBedUyqwyTTRpULidMwA296NRpk <br> Ether: 0xa5fefb7c61ba9d8029ab02e0e3ebeb8f12b4368c
</td></tr>	
	<tr><td style="font-size: 8pt">Date Updated: Wed Sept 21 22:10:39 2016</td></tr>
	
</table>
<br>
<br>
<br>
</center>
</body>

</html>